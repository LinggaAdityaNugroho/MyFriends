package com.example.myfriends

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.toast
import org.jetbrains.anko.yesButton

class AddActivity : AppCompatActivity() {

    private val database by lazy { FriendDatabase(this) }
    lateinit var friendAdapter: FriendAdapter
    private val displaySearch = ArrayList<FriendModel>()
    private val list = ArrayList<FriendModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        setupRecyclerview()
        setupListener()
    }

    private fun setupRecyclerview() {
        friendAdapter = FriendAdapter(arrayListOf(), object : FriendAdapter.onAdapterListener {
            override fun onDelete(friendModel: FriendModel) {
                alertDelete(friendModel)
            }

            override fun onEdit(friendModel: FriendModel) {
                startActivity(
                    Intent(this@AddActivity, EditActivity::class.java)
                        .putExtra("KEY_ID", friendModel.id)
                        .putExtra("ACCESS_VIEW", Mode.MODE_UPDATE)
                        .putExtra("KEY_NAME", friendModel.name)
                        .putExtra("KEY_SCHOOL", friendModel.school)
                        .putExtra("KEY_GITHUB", friendModel.github)
                )
            }

        })
        rvNewFriend.layoutManager = LinearLayoutManager(this)
        rvNewFriend.adapter = friendAdapter
    }

    private fun setupListener() {
        flAdd.setOnClickListener {
            val moveAdd = Intent(this, EditActivity::class.java)
                .putExtra("ACCESS_VIEW", Mode.MODE_TAMBAH)
            startActivity(moveAdd)
        }
    }

    private fun alertDelete(friendModel: FriendModel) {
        alert("Are you sure to delete ? ${friendModel.name}",
            "Ok") {
            yesButton {
                CoroutineScope(Dispatchers.IO).launch {
                    database.friendDao().deleteFriend(friendModel)
                    loadData()
                }
               toast("${friendModel.name}deleted")
            }
            noButton {
                toast("Cancel delete")
            }
        }.show()
    }

    override fun onStart() {
        super.onStart()
        loadData()
    }

    private fun loadData() {
        CoroutineScope(Dispatchers.IO).launch {
            val getDataFriend = database.friendDao().getFriend()
            Log.d("AddActivity", "dataFriendResponse: $getDataFriend")
            withContext(Dispatchers.Main) {
                friendAdapter.setData(getDataFriend)
            }
        }
    }

}