package com.example.myfriends

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AllActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all)
    }
}