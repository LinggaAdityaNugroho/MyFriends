package com.example.myfriends

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_add.*
import kotlinx.android.synthetic.main.activity_edit.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class EditActivity : AppCompatActivity() {

    private val database by lazy { FriendDatabase(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        saveNote()
        updateNote()
        viewNote()
    }

    private fun saveNote() {
        btnSaveEdit.setOnClickListener {
            if (edNameEdit.text?.trim().toString().isEmpty() || edNameEdit.text?.trim().toString()
                    .isEmpty()
            ) {
                edNameEdit.error = "Field tidak boleh kosong!"
                edSchoolEdit.error = "Field tidak boleh kosong"
                edGithubEdit.error = "Field tidak boleh kosong"
            } else {

                val editName = edNameEdit.text?.trim().toString()
                val editSchool = edSchoolEdit.text?.trim().toString()
                val editGithub = edGithubEdit.text?.trim().toString()
                val id = intent.getIntExtra("KEY_ID", 0)

                CoroutineScope(Dispatchers.IO).launch {
                    database.friendDao().addFriend(FriendModel(id,editName,editSchool,editGithub))
                }
                finish()
            }
        }
    }

    private fun updateNote() {
        btnSaveEdit.setOnClickListener {
            if (edNameEdit.text?.trim().toString().isEmpty() || edNameEdit.text?.trim().toString()
                    .isEmpty()
            ) {
                edNameEdit.error = "Field tidak boleh kosong!"
                edSchoolEdit.error = "Field tidak boleh kosong"
                edGithubEdit.error = "Field tidak boleh kosong"
            } else {

                val editName = edNameEdit.text?.trim().toString()
                val editSchool = edSchoolEdit.text?.trim().toString()
                val editGithub = edGithubEdit.text?.trim().toString()
                val id = intent.getIntExtra("KEY_ID", 0)

                CoroutineScope(Dispatchers.IO).launch {
                    database.friendDao().editFriend(FriendModel(id,editName,editSchool,editGithub))
                }
                finish()
            }
        }
    }

    private fun viewNote() {

        val name = intent.getStringExtra("KEY_NAME")
        val school = intent.getStringExtra("KEY_SCHOOL")
        val github = intent.getStringExtra("KEY_GITHUB")

        edNameEdit.setText(title)
        edSchoolEdit.setText(school)
        edGithubEdit.setText(github)
    }

}