package com.example.myfriends

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.anggapambudi.notes.mode.Mode
import kotlinx.android.synthetic.main.activity_detail.view.*
import kotlinx.android.synthetic.main.item_rv_new_friend.view.tvGithub
import kotlinx.android.synthetic.main.item_rv_new_friend.view.tvName
import kotlinx.android.synthetic.main.item_rv_new_friend.view.tvSchool

class FriendAdapter(private val item: ArrayList<FriendModel>, private val listener: onAdapterListener) :
        RecyclerView.Adapter<FriendAdapter.FriendViewHolder>() {

    class FriendViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)= FriendViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_rv_new_friend, parent, false)
    )

    override fun onBindViewHolder(holder: FriendViewHolder, position: Int) {
        val friendModel = item[position]
        holder.itemView.tvName.text = friendModel.name
        holder.itemView.tvSchool.text = friendModel.school
        holder.itemView.tvGithub.text = friendModel.github

        holder.itemView.btnDelete.setOnClickListener {
            listener.onDelete( friendModel )
        }
        holder.itemView.btnEdit.setOnClickListener {
            listener.onEdit( friendModel )
        }
        holder.itemView.setOnClickListener {
            val moveRead = Intent(holder.itemView.context, EditActivity::class.java)
                .putExtra("KEY_NAME", friendModel.name)
                .putExtra("KEY_SCHOOL", friendModel.school)
                .putExtra("KEY_GITHUB", friendModel.github)
                .putExtra("ACCESS_VIEW", Mode.MODE_BACA)
            holder.itemView.context.startActivity(moveRead)
        }
    }

    override fun getItemCount(): Int {
        return item.size
    }

    fun setData(data: List<FriendModel>) {
        item.clear()
        item.addAll(data)
        notifyDataSetChanged()
    }

    interface onAdapterListener {
        fun onDelete(noteModel: FriendModel)
        fun onEdit(noteModel: FriendModel)
    }

}