package com.example.myfriends

class Mode {
    companion object {
        const val MODE_BACA = 0
        const val MODE_TAMBAH = 1
        const val MODE_UPDATE = 2
    }
}