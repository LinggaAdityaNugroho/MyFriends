package com.example.myfriends

import androidx.room.*

@Dao
interface FriendDao {

    @Insert
    suspend fun addFriend(friendModel: FriendModel)

    @Update
    suspend fun editFriend(friendModel: FriendModel)

    @Delete
    suspend fun deleteFriend(friendModel: FriendModel)

    @Query("SELECT * FROM FriendModel")
    suspend fun getFriend(): List<FriendModel>

}